# =============================================================
# core/bitstream.py — Bit-Level Stream Writer
# Part of ECO (Efficient Compressed Operations)
# Handles packing individual bits into bytes for writing
# compressed Huffman-encoded data to binary files.
#
# How it works:
#   Huffman codes are variable-length bit strings (e.g. "101").
#   Files are stored in bytes (8 bits). This class bridges that
#   gap by buffering bits and flushing full bytes to storage.
# =============================================================


class BitWriter:
    """
    Writes individual bits into a byte buffer.
    Accumulates bits until a full byte (8 bits) is formed,
    then appends it to the output data array.
    """

    def __init__(self):
        """
        Initialize the BitWriter with an empty buffer.
        - buffer : holds the current partial byte being built (int)
        - bits   : count of bits currently loaded in the buffer
        - data   : final bytearray of fully packed bytes
        """
        self.buffer = 0           # Current byte being assembled (bit by bit)
        self.bits = 0             # How many bits have been written to buffer
        self.data = bytearray()   # Completed bytes ready for file output

    def write_bit(self, bit):
        """
        Write a single bit (0 or 1) into the buffer.
        When 8 bits accumulate, the byte is saved and buffer resets.

        :param bit: Integer 0 or 1
        """
        # Shift buffer left by 1 and OR in the new bit at the rightmost position
        self.buffer = (self.buffer << 1) | bit
        self.bits += 1

        # If we've filled a full byte, save it and reset the buffer
        if self.bits == 8:
            self.data.append(self.buffer)
            self.buffer = 0
            self.bits = 0

    def write_bits(self, bit_string):
        """
        Write a string of bits (e.g. "1011010") into the buffer.
        Each character in the string is written as an individual bit.

        :param bit_string: A string of '0' and '1' characters
        """
        for b in bit_string:
            self.write_bit(int(b))   # Convert '0'/'1' char to integer 0/1

    def flush(self):
        """
        Finalize the output by padding any leftover bits in the buffer
        to complete the final byte, then return all collected bytes.

        Padding is added to the RIGHT (least significant side) so the
        meaningful bits stay at the top of the last byte.

        :return: bytearray of all compressed bytes
        """
        if self.bits > 0:
            # Pad remaining bits with zeros on the right to fill the byte
            self.buffer <<= (8 - self.bits)
            self.data.append(self.buffer)

        return self.data
