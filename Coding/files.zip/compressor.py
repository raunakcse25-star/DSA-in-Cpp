# =============================================================
# core/compressor.py — Huffman File Compressor
# Part of ECO (Efficient Compressed Operations)
# Reads a text file, builds a Huffman tree, encodes every
# character into its optimal bit code, and writes the result
# as a binary .hzip archive.
#
# .hzip file format:
#   [2 bytes]  length of the original filename
#   [N bytes]  original filename (UTF-8 encoded)
#   [M bytes]  Huffman-compressed bit data
# =============================================================

from .huffman_tree import HuffmanTree   # Builds the Huffman tree and codes
from .bitstream import BitWriter        # Packs bits into bytes for file output


class Compressor:
    """
    Compresses a plain text file into a .hzip binary archive
    using Huffman coding for bit-level data reduction.
    """

    def compress_file(self, input_path, output_path):
        """
        Compress a text file and write the result to a .hzip file.

        Process:
          1. Read the full text from the input file
          2. Build a Huffman tree based on character frequencies
          3. Generate variable-length bit codes for each character
          4. Encode the entire text using those bit codes
          5. Pack the bits into bytes using BitWriter
          6. Write the filename + compressed bytes to the output file

        :param input_path:  Path to the source text file
        :param output_path: Path where the .hzip archive will be saved
        :return: The codes dictionary (char → bit string) for reference
        """

        # ── Step 1: Read input file ───────────────────────────
        with open(input_path, "r") as f:
            data = f.read()

        # ── Step 2 & 3: Build Huffman tree and generate codes ─
        tree = HuffmanTree()
        root = tree.build(data)            # Build the optimal tree
        codes = tree.generate_codes(root)  # Get char → bit string mapping

        # ── Step 4 & 5: Encode the text into bits ─────────────
        writer = BitWriter()
        for char in data:
            # Look up each character's Huffman code and write its bits
            writer.write_bits(codes[char])

        # Flush remaining bits and get the final compressed byte array
        compressed_data = writer.flush()

        # ── Step 6: Write the .hzip archive ───────────────────
        with open(output_path, "wb") as f:

            # Store the original filename in the archive header
            # so it can be recovered during decompression
            filename = input_path.encode()          # Convert path to bytes
            f.write(len(filename).to_bytes(2, "big"))  # 2-byte length prefix
            f.write(filename)                          # Actual filename bytes

            # Write the compressed bit data
            f.write(bytes(compressed_data))

        return codes
