# =============================================================
# app.py — HuffZip Pro GUI Application
# Part of ECO (Efficient Compressed Operations)
# Provides a Tkinter-based desktop interface for compressing
# and decompressing files using the Huffman algorithm.
# =============================================================

import tkinter as tk
from tkinter import filedialog, ttk, messagebox
import os
from core.compressor import Compressor       # Huffman compression engine
from core.decompressor import Decompressor   # Huffman decompression engine


class App:
    """
    Main GUI class for HuffZip Pro.
    Handles all user interactions — file selection, compression,
    decompression, progress display, and result reporting.
    """

    def __init__(self, root):
        """
        Initialize the application window and build all UI components.
        :param root: The root Tkinter window passed from main.py
        """
        self.root = root
        self.root.title("HuffZip Pro")
        self.root.geometry("420x300")
        self.root.resizable(False, False)

        # ── Title Label ──────────────────────────────────────
        title = tk.Label(
            root,
            text="HuffZip Compression Tool",
            font=("Arial", 18, "bold")
        )
        title.pack(pady=15)

        # ── Progress Bar ─────────────────────────────────────
        # Shows compression/decompression progress (0–100)
        self.progress = ttk.Progressbar(root, length=300)
        self.progress.pack(pady=10)

        # ── Button Frame ─────────────────────────────────────
        # Holds the Compress and Decompress buttons side by side
        frame = tk.Frame(root)
        frame.pack(pady=10)

        # Compress button — triggers file picker and compression
        compress_btn = tk.Button(
            frame,
            text="Compress File",
            width=18,
            bg="#4CAF50",
            fg="white",
            command=self.compress
        )
        compress_btn.grid(row=0, column=0, padx=10, pady=5)

        # Decompress button — triggers .hzip file picker and decompression
        decompress_btn = tk.Button(
            frame,
            text="Decompress File",
            width=18,
            bg="#2196F3",
            fg="white",
            command=self.decompress
        )
        decompress_btn.grid(row=0, column=1, padx=10, pady=5)

        # ── Result Label ─────────────────────────────────────
        # Displays compression stats or decompression output path
        self.result = tk.Label(
            root,
            text="",
            font=("Arial", 10)
        )
        self.result.pack(pady=15)

        # ── Exit Button ──────────────────────────────────────
        exit_btn = tk.Button(
            root,
            text="Exit",
            width=10,
            command=root.quit
        )
        exit_btn.pack(pady=5)

    # ─────────────────────────────────────────────────────────
    # Compress Function
    # ─────────────────────────────────────────────────────────
    def compress(self):
        """
        Opens a file picker dialog, compresses the selected file
        using Huffman coding, and displays compression statistics.
        Output file is saved with a .hzip extension.
        """
        # Open file picker — any file type allowed
        path = filedialog.askopenfilename()
        if not path:
            return  # User cancelled the dialog

        try:
            # Update progress bar to show work has started
            self.progress["value"] = 20
            self.root.update()

            # Define output path — same location, .hzip extension
            output = path + ".hzip"

            # Run Huffman compression
            comp = Compressor()
            comp.compress_file(path, output)

            # Mark progress as complete
            self.progress["value"] = 100

            # Calculate compression statistics
            original = os.path.getsize(path)       # Original file size in bytes
            compressed = os.path.getsize(output)   # Compressed file size in bytes
            saved = original - compressed           # Bytes saved
            ratio = compressed / original           # Compression ratio (lower = better)

            # Display stats in the result label
            self.result.config(
                text=f"""Compression Complete
Original Size  : {original} bytes
Compressed Size: {compressed} bytes
Saved          : {saved} bytes
Ratio          : {ratio:.2f}"""
            )

            messagebox.showinfo("Success", "File compressed successfully")

        except Exception as e:
            messagebox.showerror("Error", str(e))

        finally:
            # Always reset the progress bar after operation
            self.progress["value"] = 0

    # ─────────────────────────────────────────────────────────
    # Decompress Function
    # ─────────────────────────────────────────────────────────
    def decompress(self):
        """
        Opens a file picker filtered to .hzip files, decompresses
        the selected archive, and saves the result as a .txt file.
        """
        # Open file picker — only show .hzip files
        path = filedialog.askopenfilename(
            filetypes=[("HuffZip Archive", "*.hzip")]
        )
        if not path:
            return  # User cancelled the dialog

        try:
            # Update progress bar to show work has started
            self.progress["value"] = 30
            self.root.update()

            # Define output path — replace .hzip with _decompressed.txt
            output = path.replace(".hzip", "_decompressed.txt")

            # Run Huffman decompression
            decomp = Decompressor()
            decomp.decompress_file(path, output)

            # Mark progress as complete
            self.progress["value"] = 100

            # Show the output file path in the result label
            self.result.config(
                text=f"""Decompression Complete
Output File: {output}"""
            )

            messagebox.showinfo("Success", "File decompressed successfully")

        except Exception as e:
            messagebox.showerror("Error", str(e))

        finally:
            # Always reset the progress bar after operation
            self.progress["value"] = 0
