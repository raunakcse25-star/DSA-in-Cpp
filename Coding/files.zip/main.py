# =============================================================
# main.py — Application Entry Point
# Part of ECO (Efficient Compressed Operations)
# Launches the HuffZip Pro GUI by creating the root Tkinter
# window and passing it to the App class.
#
# Run this file to start the application:
#   python main.py
# =============================================================

import tkinter as tk
from app import App       # Main GUI application class


def main():
    """
    Initialize the Tkinter root window and launch the HuffZip Pro app.
    The mainloop() call keeps the window open and responsive
    until the user closes it or clicks Exit.
    """
    # Create the root window — this is the main OS window
    root = tk.Tk()

    # Pass the root window to App which builds all UI components
    App(root)

    # Start the Tkinter event loop — listens for clicks, inputs, etc.
    # This is a blocking call; it returns only when the window is closed.
    root.mainloop()


# Only run main() when this file is executed directly.
# Prevents auto-launch if main.py is imported elsewhere.
if __name__ == "__main__":
    main()
