# =============================================================
# cli.py — Command Line Interface for HuffZip Pro
# Part of ECO (Efficient Compressed Operations)
# Allows compression directly from the terminal without
# launching the GUI — useful for scripting and automation.
#
# Usage:
#   python cli.py -c <input_file> -o <output_file>
#
# Example:
#   python cli.py -c data.txt -o data.hzip
# =============================================================

import argparse
from core.compressor import Compressor   # Huffman compression engine


def main():
    """
    Entry point for the CLI tool.
    Parses command-line arguments and triggers file compression.
    """

    # ── Argument Parser Setup ─────────────────────────────────
    parser = argparse.ArgumentParser(
        description="HuffZip Pro — Huffman Compression CLI"
    )

    # -c / --compress : path to the input file to compress
    parser.add_argument(
        "-c", "--compress",
        help="Path to the input file you want to compress",
        required=True
    )

    # -o / --output : path where the compressed .hzip file will be saved
    parser.add_argument(
        "-o", "--output",
        help="Path for the output compressed file (e.g. output.hzip)",
        required=True
    )

    # Parse the arguments from the command line
    args = parser.parse_args()

    # ── Run Compression ───────────────────────────────────────
    comp = Compressor()
    comp.compress_file(args.compress, args.output)

    print(f"Compressed: {args.compress} → {args.output}")


# Run main() only when this file is executed directly
# (not when imported as a module)
if __name__ == "__main__":
    main()
