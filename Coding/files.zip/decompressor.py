# =============================================================
# core/decompressor.py — Huffman File Decompressor
# Part of ECO (Efficient Compressed Operations)
# Reads a .hzip binary archive, extracts the original filename
# and compressed bit data, then decodes and writes the output.
#
# NOTE: The current decode logic is a placeholder that outputs
# the raw bit string. Full Huffman tree decoding (using a
# stored tree or frequency table) can be added in a future PR.
#
# .hzip file format (must match compressor.py):
#   [2 bytes]  length of the original filename
#   [N bytes]  original filename (UTF-8 encoded)
#   [M bytes]  Huffman-compressed bit data
# =============================================================

from core.huffman_tree import HuffmanTree   # Available for full decode (future)


class Decompressor:
    """
    Decompresses a .hzip archive back into a readable text file.
    """

    def decompress_file(self, input_path, output_path):
        """
        Read a .hzip archive and write the decompressed output.

        Process:
          1. Read the filename length from the 2-byte header
          2. Read and decode the original filename
          3. Read the remaining bytes as compressed data
          4. Convert each byte back into its 8-bit binary string
          5. Decode the bit string back to text (placeholder)
          6. Write the result to the output file

        :param input_path:  Path to the .hzip compressed archive
        :param output_path: Path where the decompressed file will be saved
        """

        # ── Step 1–3: Parse the .hzip archive header ──────────
        with open(input_path, "rb") as f:

            # Read the 2-byte big-endian integer = length of filename
            name_length = int.from_bytes(f.read(2), "big")

            # Read exactly name_length bytes and decode as UTF-8 filename
            filename = f.read(name_length).decode()

            # Everything after the header is the compressed bit data
            compressed_data = f.read()

        # ── Step 4: Convert compressed bytes → bit string ─────
        # Each byte is converted to its 8-character binary representation
        # e.g. byte 0b10110010 (178) → "10110010"
        bit_string = ""
        for byte in compressed_data:
            bit_string += format(byte, "08b")   # Zero-padded 8-bit string

        # ── Step 5: Decode bit string → original text ─────────
        # TODO: Implement full Huffman tree decoding.
        # This requires storing the Huffman codes or frequency table
        # inside the .hzip archive during compression so the tree
        # can be reconstructed here for accurate decoding.
        #
        # Current behaviour: writes the raw bit string as a placeholder.
        decoded_text = bit_string

        # ── Step 6: Write output file ──────────────────────────
        with open(output_path, "w") as f:
            f.write(decoded_text)
