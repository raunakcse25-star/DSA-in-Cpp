# =============================================================
# core/huffman_tree.py — Huffman Tree Builder & Code Generator
# Part of ECO (Efficient Compressed Operations)
# Implements the core Huffman coding algorithm from scratch:
#   1. Count character frequencies in the input data
#   2. Build a min-heap priority queue of leaf nodes
#   3. Merge nodes into a binary tree (lowest freq first)
#   4. Traverse the tree to generate variable-length bit codes
#
# Characters that appear more often get shorter codes,
# reducing the total number of bits needed to store the data.
# =============================================================

import heapq                  # Min-heap for efficient node merging
from collections import Counter  # Fast frequency counting


class Node:
    """
    Represents a single node in the Huffman binary tree.
    Leaf nodes store a character; internal nodes store only frequency.
    """

    def __init__(self, char=None, freq=0):
        """
        :param char: The character this node represents (None for internal nodes)
        :param freq: Frequency (count) of this character in the input data
        """
        self.char = char    # Character (only set on leaf nodes)
        self.freq = freq    # Frequency used for priority queue ordering
        self.left = None    # Left child node  (represents bit '0')
        self.right = None   # Right child node (represents bit '1')

    def __lt__(self, other):
        """
        Comparison method required by heapq.
        Nodes with lower frequency have higher priority (min-heap).
        :param other: Another Node to compare against
        """
        return self.freq < other.freq


class HuffmanTree:
    """
    Builds a Huffman Tree from input text and generates
    the optimal binary codes for each unique character.
    """

    def build(self, data):
        """
        Build the Huffman Tree from the input string.

        Steps:
          1. Count how often each character appears (frequency table)
          2. Create a leaf Node for each character
          3. Push all nodes into a min-heap
          4. Repeatedly merge the two lowest-frequency nodes
             until only one node (the root) remains

        :param data: Input string to build the tree from
        :return: Root Node of the completed Huffman tree
        """
        # Step 1: Count character frequencies
        # e.g. "aab" → {'a': 2, 'b': 1}
        freq = Counter(data)

        # Step 2 & 3: Create leaf nodes and push into min-heap
        heap = []
        for char, f in freq.items():
            heapq.heappush(heap, Node(char, f))

        # Step 4: Merge nodes until only the root remains
        while len(heap) > 1:
            # Pop the two nodes with the lowest frequencies
            n1 = heapq.heappop(heap)   # Lowest frequency
            n2 = heapq.heappop(heap)   # Second lowest frequency

            # Create a new internal node whose frequency is their sum
            # This internal node has no character (char=None)
            merged = Node(None, n1.freq + n2.freq)
            merged.left = n1    # Left child → bit '0'
            merged.right = n2   # Right child → bit '1'

            # Push the merged node back into the heap
            heapq.heappush(heap, merged)

        # The last remaining node is the root of the tree
        return heap[0]

    def generate_codes(self, root):
        """
        Traverse the Huffman tree and generate a binary code
        for each character (leaf node).

        Left branch = '0', Right branch = '1'
        The code for each character is the path from root to its leaf.

        Example tree result:
          'a' → "0"
          'b' → "10"
          'c' → "11"

        :param root: Root Node of the Huffman tree
        :return: Dictionary mapping each character to its bit code string
                 e.g. {'a': '0', 'b': '10', 'c': '11'}
        """
        codes = {}

        def traverse(node, code):
            """
            Recursive helper to walk the tree depth-first.
            :param node: Current node being visited
            :param code: Bit string accumulated on the path so far
            """
            if node is None:
                return

            # Leaf node — this node holds an actual character
            if node.char is not None:
                codes[node.char] = code
                return

            # Internal node — go left (add '0') and right (add '1')
            traverse(node.left, code + "0")
            traverse(node.right, code + "1")

        traverse(root, "")
        return codes
