# =============================================================
# security.py — Password Hashing & Verification
# Part of ECO (Efficient Compressed Operations)
# Provides basic cryptographic utilities for securing
# compressed archives with password protection.
#
# Algorithm: SHA-256 (from Python's built-in hashlib)
# SHA-256 is a one-way hash — passwords are never stored
# in plain text, only their hash fingerprints are kept.
# =============================================================

import hashlib


def hash_password(password):
    """
    Hash a plain-text password using SHA-256.

    The password is encoded to bytes first, then hashed.
    Returns a 64-character hexadecimal string representing
    the hash digest — this is what gets stored, never the
    original password.

    :param password: Plain-text password string
    :return: SHA-256 hex digest string (64 characters)

    Example:
        hash_password("mypassword")
        # → "89e01536ac207279409d4de1e5253e01..."
    """
    return hashlib.sha256(password.encode()).hexdigest()


def verify(password, stored):
    """
    Verify a plain-text password against a stored SHA-256 hash.

    Re-hashes the input password and compares it to the stored
    hash. Returns True only if they match exactly.

    :param password: Plain-text password to check
    :param stored:   Previously stored SHA-256 hash to compare against
    :return: True if the password matches, False otherwise

    Example:
        stored_hash = hash_password("mypassword")
        verify("mypassword", stored_hash)   # → True
        verify("wrongpass",  stored_hash)   # → False
    """
    return hash_password(password) == stored
