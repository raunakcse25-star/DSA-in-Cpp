# =============================================================
# filesystem.py — File System Utility
# Part of ECO (Efficient Compressed Operations)
# Provides helper functions for scanning directories and
# collecting file paths — used to feed multiple files into
# the compression pipeline at once.
# =============================================================

import os


def scan_folder(folder):
    """
    Recursively walk a folder and collect the full paths of
    all files found inside it (including all subdirectories).

    Use this to get a list of files before batch-compressing
    an entire directory with HuffZip Pro.

    :param folder: Path to the root folder to scan
    :return: List of absolute file paths found in the folder tree

    Example:
        files = scan_folder("C:/Users/RAUNAK/Documents")
        # returns ["C:/Users/RAUNAK/Documents/notes.txt",
        #          "C:/Users/RAUNAK/Documents/data/log.txt", ...]
    """
    files = []

    # os.walk yields (current_dir, subdirs, filenames) for every folder level
    for root, dirs, filenames in os.walk(folder):
        for f in filenames:
            # Build the full absolute path for each file
            files.append(os.path.join(root, f))

    return files
