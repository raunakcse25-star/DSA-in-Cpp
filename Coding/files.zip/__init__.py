# =============================================================
# core/__init__.py — Core Package Initializer
# Part of ECO (Efficient Compressed Operations)
# Marks the `core` directory as a Python package so its
# modules can be imported using dot notation:
#
#   from core.compressor import Compressor
#   from core.decompressor import Decompressor
#   from core.huffman_tree import HuffmanTree
#   from core.bitstream import BitWriter
#
# This file is intentionally kept empty — no startup logic
# is needed at the package level.
# =============================================================
