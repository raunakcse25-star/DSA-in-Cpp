# =============================================================
# logger.py — Application Logger
# Part of ECO (Efficient Compressed Operations)
# Sets up a simple file-based logger that records compression
# and decompression events with timestamps.
#
# Log file: huffzip.log (created in the working directory)
# Log level: INFO and above (INFO, WARNING, ERROR, CRITICAL)
# Log format: 2026-03-24 12:00:00,000 INFO Your message here
# =============================================================

import logging

# ── Logger Configuration ──────────────────────────────────────
# All log entries are written to huffzip.log in append mode.
# The format includes timestamp, severity level, and message.
logging.basicConfig(
    filename="huffzip.log",           # Output log file name
    level=logging.INFO,               # Minimum severity to record
    format="%(asctime)s %(levelname)s %(message)s"  # Log entry format
)


def log(message):
    """
    Write an INFO-level message to the huffzip.log file.

    Call this throughout the compression/decompression process
    to keep a record of operations for debugging and auditing.

    :param message: String message to write to the log file

    Example:
        log("Compression started: data.txt")
        log("Compressed 4096 bytes → 1024 bytes (ratio: 0.25)")
        log("Decompression complete: output.txt written")
    """
    logging.info(message)
